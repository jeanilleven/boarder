bootstrap 3.3.7
with js therefore jquery

Sir most buttons will not work because they for the most part interact with a database which we have yet to design.
